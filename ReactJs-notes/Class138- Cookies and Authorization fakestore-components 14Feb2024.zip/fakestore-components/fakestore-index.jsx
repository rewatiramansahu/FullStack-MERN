import { useState } from "react";

export function FakestoreIndex(){

    

    return (
        <div className="container-fluid">
            
            <section>
                <main className="text-center">
                    <h1>Fakestore - Online Shopping</h1>
                    
                </main>
            </section>
        </div>
    )
}